"""Import all submodules of admet_ai."""
from admet_ai.admet_model import ADMETModel
from admet_ai.admet_predict import admet_predict

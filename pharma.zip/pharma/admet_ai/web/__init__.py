from admet_ai.web.run import admet_web
